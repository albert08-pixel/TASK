# Task-App
Simple task app to let you store a task and reminds you about a task.
